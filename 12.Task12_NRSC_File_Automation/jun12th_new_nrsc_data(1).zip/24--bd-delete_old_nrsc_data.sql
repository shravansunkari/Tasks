/*
 * Delete old nrsc data and it's file meta data
 */

delete from nrsc_file_upload;

delete from soil_moisture_nrsc_data;
