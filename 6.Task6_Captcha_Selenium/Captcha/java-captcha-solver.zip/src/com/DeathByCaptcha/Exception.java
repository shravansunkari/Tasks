package com.DeathByCaptcha;


abstract public class Exception extends java.lang.Exception
{
    public Exception(String message)
    {
        super(message);
    }
}
