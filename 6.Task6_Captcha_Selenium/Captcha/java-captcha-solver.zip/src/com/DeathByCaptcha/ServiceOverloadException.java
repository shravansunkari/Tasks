package com.DeathByCaptcha;


public class ServiceOverloadException extends Exception
{
    public ServiceOverloadException(String message)
    {
        super(message);
    }
}
